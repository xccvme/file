dialog --title "Tiket Playground" --backtitle "Playground"  --msgbox "Total $jmlh * 145000 = `expr  $jmlh \* 145000`" 9 50 ;
rm -f /tmp/input.$$
